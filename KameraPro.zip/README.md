# Kamera Pro (General Mobile GM 24 Pro için)
1. Bu klasörü yeni bir GitHub deposuna yükle (push).
2. Actions sekmesi > "APK Derle" çalışır (veya Run workflow).
3. Bitince "KameraPro-APK" artifact'ını indir, zip'ten çıkan APK'yı kur.
Not: Derleme hatası olursa Actions günlüğünü bana yapıştır, düzeltirim.
