package tr.kamerapro

import android.content.Intent
import androidx.camera.core.ImageCapture
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.FlashAuto
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Gold = Color(0xFFFFD54F)

@Composable
fun CameraScreen(c: CamController) {
    val owner = LocalLifecycleOwner.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pv by remember { mutableStateOf<PreviewView?>(null) }
    var focusPt by remember { mutableStateOf<Offset?>(null) }
    var countdown by remember { mutableIntStateOf(0) }
    var evOpen by remember { mutableStateOf(false) }
    var proSel by remember { mutableStateOf("ISO") }

    LaunchedEffect(pv) { pv?.let { c.start(owner, it) } }
    LaunchedEffect(focusPt) { if (focusPt != null) { delay(1600); focusPt = null } }
    LaunchedEffect(c.ai, c.mode, c.busy, c.recording) {
        val live = c.ai && !c.busy && c.mode != Mode.VIDEO && c.mode != Mode.PRO
        if (!live) return@LaunchedEffect
        while (true) { c.refreshScene(); delay(2500) }
    }

    val video = c.mode == Mode.VIDEO
    Box(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        // ---------- Vizör ----------
        Box(
            Modifier.align(Alignment.TopCenter).padding(top = 52.dp).fillMaxWidth()
                .aspectRatio(if (video) 9f / 16f else 3f / 4f)
                .clip(RoundedCornerShape(if (video) 0.dp else 14.dp))
        ) {
            AndroidView(
                factory = { PreviewView(it).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    pv = this
                } }, modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { o -> focusPt = o; c.focusAt(o.x, o.y) } }
                .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> c.zoomBy(z) } })
            Canvas(Modifier.fillMaxSize()) {
                if (c.grid) {
                    val col = Color.White.copy(alpha = 0.35f)
                    for (i in 1..2) {
                        drawLine(col, Offset(size.width * i / 3, 0f), Offset(size.width * i / 3, size.height), 1.dp.toPx())
                        drawLine(col, Offset(0f, size.height * i / 3), Offset(size.width, size.height * i / 3), 1.dp.toPx())
                    }
                }
                focusPt?.let { drawCircle(Gold, 34.dp.toPx(), it, style = Stroke(2.dp.toPx())) }
            }
            c.sceneLabel?.let {
                if (c.ai) Row(
                    Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.45f)).padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Gold, modifier = Modifier.size(14.dp))
                    Text("  AI · $it", color = Color.White, fontSize = 12.sp)
                }
            }
            if (c.zoom > 1.05f) Text("%.1fx".format(c.zoom), color = Gold, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp))
            if (c.recording) Text("● %02d:%02d".format(c.recSeconds / 60, c.recSeconds % 60), color = Color.Red,
                fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp))
            if (countdown > 0) Text("$countdown", color = Color.White, fontSize = 96.sp, modifier = Modifier.align(Alignment.Center))
            if (evOpen) Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp, start = 24.dp, end = 24.dp)
                    .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("☀", color = Gold)
                Slider(value = c.evIdx.toFloat(), onValueChange = { c.setEv(it.toInt()) },
                    valueRange = c.evMin.toFloat()..(c.evMax.toFloat().coerceAtLeast(c.evMin + 1f)),
                    colors = gold(), modifier = Modifier.weight(1f))
                Text("%+.1f".format(c.evIdx * c.evStep), color = Color.White, fontSize = 12.sp)
            }
            if (c.busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Gold)
                    Text(c.status ?: "", color = Color.White, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }

        // ---------- Üst çubuk ----------
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            if (!c.front) Icon(
                when (c.flash) { ImageCapture.FLASH_MODE_ON -> Icons.Rounded.FlashOn
                    ImageCapture.FLASH_MODE_AUTO -> Icons.Rounded.FlashAuto else -> Icons.Rounded.FlashOff },
                null, tint = if (c.flash == ImageCapture.FLASH_MODE_OFF) Color.White else Gold,
                modifier = Modifier.size(26.dp).clickable { c.cycleFlash() })
            Chip("AI", c.ai) { c.toggleAi() }
            if (c.mode == Mode.PHOTO) Chip("HDR+", c.hdr) { c.toggleHdr() }
            Chip(if (c.timer == 0) "⏱" else "⏱ ${c.timer}s", c.timer > 0) { c.timer = when (c.timer) { 0 -> 3; 3 -> 10; else -> 0 } }
            Chip("▦", c.grid) { c.grid = !c.grid }
            Chip("☀", evOpen) { evOpen = !evOpen }
        }

        // ---------- Alt kontroller ----------
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f), Color.Black)))
                .padding(top = 18.dp, bottom = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (c.mode == Mode.PRO) ProPanel(c, proSel) { proSel = it }
            if (!c.front && c.lenses.size > 1 && !c.recording) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                c.lenses.forEachIndexed { i, l ->
                    val sel = i == c.lensIdx
                    Box(Modifier.size(38.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f))
                        .border(1.dp, if (sel) Gold else Color.Gray, CircleShape).clickable { c.selectLens(i) },
                        Alignment.Center) { Text(l.label, color = if (sel) Gold else Color.White, fontSize = 12.sp) }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                Mode.values().forEach { m ->
                    Text(m.label, color = if (m == c.mode) Gold else Color.White.copy(alpha = 0.75f),
                        fontSize = 14.sp, fontWeight = if (m == c.mode) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable { c.setMode(m) })
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Color.DarkGray).clickable {
                    c.lastUri?.let { u ->
                        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, if (video) "video/*" else "image/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }) { c.thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) } }

                Shutter(video, c.recording, c.busy || countdown > 0) {
                    scope.launch {
                        if (video) c.toggleRecord() else {
                            if (c.timer > 0) { for (i in c.timer downTo 1) { countdown = i; delay(1000) }; countdown = 0 }
                            c.shoot()
                        }
                    }
                }
                Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)).clickable { c.flip() },
                    Alignment.Center) { Icon(Icons.Rounded.Cameraswitch, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
            }
        }
    }
}

@Composable
private fun gold() = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Color.DarkGray)

@Composable
private fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    Text(text, color = if (on) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) Gold else Color.White.copy(alpha = 0.14f))
            .clickable { onClick() }.padding(horizontal = 11.dp, vertical = 6.dp))
}

@Composable
private fun Shutter(video: Boolean, rec: Boolean, disabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(78.dp).border(4.dp, Color.White, CircleShape).padding(7.dp)
        .clip(if (rec) RoundedCornerShape(14.dp) else CircleShape)
        .background(if (video) Color(0xFFE53935) else Color.White.copy(alpha = if (disabled) 0.4f else 1f))
        .clickable(enabled = !disabled) { onClick() })
}

@Composable
private fun ProPanel(c: CamController, sel: String, onSel: (String) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Chip(if (c.proManual) "M" else "A", c.proManual) { c.setProManual(!c.proManual) }
            Chip("ISO ${if (c.proManual) c.isoValue() else "Oto"}", sel == "ISO") { onSel("ISO") }
            Chip("S ${if (c.proManual) c.shutterText() else "Oto"}", sel == "S") { onSel("S") }
            Chip("WB ${c.awbNames[c.awbIdx]}", sel == "WB") { onSel("WB") }
            Chip("MF ${if (c.manualFocus) c.focusText() else "AF"}", sel == "MF") { onSel("MF") }
        }
        when (sel) {
            "ISO" -> Slider(c.isoF, { c.setIso(it) }, colors = gold(), enabled = c.proManual)
            "S" -> Slider(c.shutF, { c.setShutter(it) }, colors = gold(), enabled = c.proManual)
            "MF" -> Slider(c.focusF, { c.setFocus(it) }, colors = gold())
            "WB" -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                c.awbNames.forEachIndexed { i, n -> Chip(n, i == c.awbIdx) { c.setAwb(i) } }
            }
        }
    }
}
