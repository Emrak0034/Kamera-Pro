package tr.kamerapro

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import android.widget.Toast
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.opencv.core.Mat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.roundToInt

enum class Mode(val label: String) {
    VIDEO("VİDEO"), PHOTO("FOTOĞRAF"), PORTRAIT("PORTRE"), NIGHT("GECE"), PRO("PRO")
}

data class Lens(val id: String, val label: String)
private class RawFrame(val bytes: ByteArray, val rot: Int)

class CamController(private val ctx: Context) {
    private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val io = Executors.newSingleThreadExecutor()
    private val main = ContextCompat.getMainExecutor(ctx)

    private var provider: ProcessCameraProvider? = null
    private var owner: LifecycleOwner? = null
    private var pv: PreviewView? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recordingHandle: Recording? = null
    private var chars: CameraCharacteristics? = null
    private var frontId: String? = null
    private var backIds: List<String> = emptyList()
    var lastUri: Uri? = null; private set

    // ---- UI durumu ----
    var mode by mutableStateOf(Mode.PHOTO); private set
    var front by mutableStateOf(false); private set
    var lenses by mutableStateOf<List<Lens>>(emptyList()); private set
    var lensIdx by mutableIntStateOf(0); private set
    var flash by mutableIntStateOf(ImageCapture.FLASH_MODE_OFF); private set
    var ai by mutableStateOf(true); private set
    var hdr by mutableStateOf(true); private set
    var grid by mutableStateOf(true)
    var timer by mutableIntStateOf(0)
    var busy by mutableStateOf(false); private set
    var status by mutableStateOf<String?>(null); private set
    var sceneLabel by mutableStateOf<String?>(null); private set
    var thumb by mutableStateOf<Bitmap?>(null); private set
    var zoom by mutableFloatStateOf(1f); private set
    private var minZoom = 1f
    private var maxZoom = 8f
    var recording by mutableStateOf(false); private set
    var recSeconds by mutableIntStateOf(0); private set
    var evIdx by mutableIntStateOf(0); private set
    var evMin by mutableIntStateOf(0); private set
    var evMax by mutableIntStateOf(0); private set
    var evStep by mutableFloatStateOf(0.1f); private set

    // ---- Pro ----
    var proManual by mutableStateOf(false); private set
    var isoF by mutableFloatStateOf(0.25f); private set
    var shutF by mutableFloatStateOf(0.55f); private set
    var focusF by mutableFloatStateOf(0f); private set
    var manualFocus by mutableStateOf(false); private set
    var awbIdx by mutableIntStateOf(0); private set
    val awbNames = listOf("Oto", "Gün ışığı", "Bulutlu", "Tungsten", "Floresan")
    private val awbModes = listOf(
        CaptureRequest.CONTROL_AWB_MODE_AUTO, CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
        CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
        CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
    )
    private var isoLo = 100; private var isoHi = 1600
    private var expLo = 125_000L; private var expHi = 1_000_000_000L
    private var minFocus = 0f

    fun isoValue() = (isoLo * (isoHi.toFloat() / isoLo).pow(isoF)).roundToInt().coerceIn(isoLo, isoHi)
    fun shutterNs() = (expLo * (expHi.toDouble() / expLo).pow(shutF.toDouble())).toLong().coerceIn(expLo, expHi)
    fun shutterText(): String {
        val ns = shutterNs()
        return if (ns >= 400_000_000L) "%.1f sn".format(ns / 1e9) else "1/${(1e9 / ns).roundToInt()}"
    }
    fun focusText() = if (focusF <= 0.01f) "∞" else "%.0f cm".format(100f / (focusF * minFocus.coerceAtLeast(0.1f)))

    // ---------- Başlatma ----------
    suspend fun start(o: LifecycleOwner, view: PreviewView) {
        owner = o; pv = view
        Enhancer.init()
        provider = suspendCoroutine { c ->
            val f = ProcessCameraProvider.getInstance(ctx)
            f.addListener({ c.resume(f.get()) }, main)
        }
        discoverLenses(); bind()
    }

    private fun discoverLenses() {
        val p = provider ?: return
        class Cam(val id: String, val equiv: Double)
        val backs = ArrayList<Cam>()
        for (info in p.availableCameraInfos) {
            val id = Camera2CameraInfo.from(info).cameraId
            val ch = cm.getCameraCharacteristics(id)
            val facing = ch.get(CameraCharacteristics.LENS_FACING)
            if (facing == CameraCharacteristics.LENS_FACING_FRONT) { if (frontId == null) frontId = id; continue }
            val f = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.minOrNull() ?: continue
            val sz = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: continue
            backs.add(Cam(id, f * 43.27 / hypot(sz.width.toDouble(), sz.height.toDouble())))
        }
        if (backs.isEmpty()) return
        val main = backs.minByOrNull { kotlin.math.abs(it.equiv - 26.0) }!!
        val out = ArrayList<Lens>(); val seen = HashSet<String>()
        for (c in backs.sortedBy { it.equiv }) {
            val r = c.equiv / main.equiv
            val label = if (r in 0.93..1.07) "1x" else "%.1fx".format(r).replace(".0x", "x")
            if (seen.add(label)) out.add(Lens(c.id, label))
        }
        lenses = out; backIds = out.map { it.id }
        lensIdx = out.indexOfFirst { it.id == main.id }.coerceAtLeast(0)
    }

    private fun selectorFor(id: String) = CameraSelector.Builder()
        .addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == id } }.build()

    private fun IntArray?.has(v: Int) = this?.contains(v) == true

    /** Donanım ISP'sinin en kaliteli gürültü/kenar/renk sapması modlarını (destekleniyorsa) açar. */
    private fun <T> Camera2Interop.Extender<T>.quality(ch: CameraCharacteristics, postSharpen: Boolean) {
        val nr = CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES
        if (ch.get(nr).has(CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY))
            setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        val em = ch.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
        val edge = if (postSharpen && em.has(CaptureRequest.EDGE_MODE_FAST)) CaptureRequest.EDGE_MODE_FAST
        else CaptureRequest.EDGE_MODE_HIGH_QUALITY
        if (em.has(edge)) setCaptureRequestOption(CaptureRequest.EDGE_MODE, edge)
        if (ch.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES)
                .has(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY))
            setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
        if (ch.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES).has(CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY))
            setCaptureRequestOption(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY)
        if (ch.get(CameraCharacteristics.SHADING_AVAILABLE_MODES).has(CaptureRequest.SHADING_MODE_HIGH_QUALITY))
            setCaptureRequestOption(CaptureRequest.SHADING_MODE, CaptureRequest.SHADING_MODE_HIGH_QUALITY)
    }

    private fun resSel(ratio: AspectRatioStrategy, size: Size? = null): ResolutionSelector {
        val b = ResolutionSelector.Builder().setAspectRatioStrategy(ratio)
        if (size != null) b.setResolutionStrategy(ResolutionStrategy(size, ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
        return b.build()
    }

    fun bind() {
        val p = provider ?: return; val o = owner ?: return; val view = pv ?: return
        if (recordingHandle != null) return
        p.unbindAll()
        val id = if (front) (frontId ?: return) else (lenses.getOrNull(lensIdx)?.id ?: backIds.firstOrNull() ?: return)
        val ch = cm.getCameraCharacteristics(id); chars = ch
        val video = mode == Mode.VIDEO
        val ratio = if (video) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY

        val preview = Preview.Builder().setResolutionSelector(resSel(ratio)).build()
            .also { it.setSurfaceProvider(view.surfaceProvider) }
        val cases = ArrayList<UseCase>(); cases.add(preview)

        if (video) {
            val rec = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HIGHEST)).build()
            val vb = VideoCapture.Builder(rec)
            if (ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                    .has(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON))
                Camera2Interop.Extender(vb).setCaptureRequestOption(
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            val vc = vb.build(); videoCapture = vc; imageCapture = null; cases.add(vc)
        } else {
            val burst = mode == Mode.NIGHT || mode == Mode.PORTRAIT || (mode == Mode.PHOTO && hdr)
            val size = if (burst) Size(3264, 2448) else Size(4096, 3072)
            val processed = ai && mode != Mode.PRO
            val ib = ImageCapture.Builder()
                .setCaptureMode(if (burst) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(resSel(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY, size))
                .setJpegQuality(100).setFlashMode(flash)
            Camera2Interop.Extender(ib).quality(ch, processed)
            val ic = ib.build(); imageCapture = ic; videoCapture = null; cases.add(ic)
        }

        val cam = p.bindToLifecycle(o, selectorFor(id), *cases.toTypedArray()); camera = cam
        cam.cameraInfo.zoomState.observe(o) { z -> minZoom = z.minZoomRatio; maxZoom = z.maxZoomRatio; zoom = z.zoomRatio }
        val es = cam.cameraInfo.exposureState
        evMin = es.exposureCompensationRange.lower; evMax = es.exposureCompensationRange.upper
        evStep = es.exposureCompensationStep.toFloat(); evIdx = 0

        ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { isoLo = it.lower; isoHi = minOf(it.upper, 6400) }
        ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let {
            expLo = maxOf(it.lower, 125_000L); expHi = minOf(it.upper, 1_000_000_000L)
        }
        minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        applyPro()
    }

    // ---------- Basit kontroller ----------
    fun setMode(m: Mode) { if (recordingHandle != null || busy) return; mode = m; bind() }
    fun flip() { if (recordingHandle != null || busy) return; front = !front; bind() }
    fun selectLens(i: Int) { if (busy) return; front = false; lensIdx = i; bind() }
    fun cycleFlash() {
        flash = when (flash) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flash
    }
    fun toggleAi() { ai = !ai; if (ai.not()) sceneLabel = null; bind() }
    fun toggleHdr() { hdr = !hdr; bind() }
    fun zoomBy(s: Float) { val z = (zoom * s).coerceIn(minZoom, maxZoom); camera?.cameraControl?.setZoomRatio(z); zoom = z }
    fun setEv(i: Int) { evIdx = i.coerceIn(evMin, evMax); camera?.cameraControl?.setExposureCompensationIndex(evIdx) }
    fun focusAt(x: Float, y: Float) {
        val v = pv ?: return
        val pt = v.meteringPointFactory.createPoint(x, y)
        camera?.cameraControl?.startFocusAndMetering(
            FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB)
                .setAutoCancelDuration(4, TimeUnit.SECONDS).build())
    }

    // ---------- Pro ----------
    fun setProManual(b: Boolean) { proManual = b; applyPro() }
    fun setIso(f: Float) { isoF = f; applyPro() }
    fun setShutter(f: Float) { shutF = f; applyPro() }
    fun setFocus(f: Float) { focusF = f; manualFocus = f > 0.005f; applyPro() }
    fun setAwb(i: Int) { awbIdx = i; applyPro() }

    private fun applyPro() {
        val cam = camera ?: return
        val b = CaptureRequestOptions.Builder()
        if (mode == Mode.PRO) {
            if (proManual) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoValue())
                b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs())
            }
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, awbModes[awbIdx])
            if (manualFocus && minFocus > 0f) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusF * minFocus)
            }
        }
        Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
    }

    // ---------- Yapay zeka sahne rozeti ----------
    suspend fun refreshScene() {
        val v = pv ?: return
        val bmp = v.bitmap ?: return
        val small = Bitmap.createScaledBitmap(bmp, 320, (320f * bmp.height / bmp.width).toInt().coerceAtLeast(1), true)
        val s = try { Enhancer.detectScene(small) } catch (e: Exception) { Scene.AUTO }
        sceneLabel = s.tr
    }

    // ---------- Çekim ----------
    private suspend fun grab(ic: ImageCapture): RawFrame = suspendCancellableCoroutine { c ->
        ic.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val buf = image.planes[0].buffer
                    val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                    c.resume(RawFrame(bytes, image.imageInfo.rotationDegrees))
                } catch (e: Exception) { c.resumeWithException(e) } finally { image.close() }
            }
            override fun onError(e: ImageCaptureException) { c.resumeWithException(e) }
        })
    }

    private suspend fun grabMat(ic: ImageCapture): Pair<Mat, Int> {
        val f = grab(ic)
        return withContext(Dispatchers.Default) { Enhancer.decode(f.bytes) } to f.rot
    }

    suspend fun shoot() {
        val ic = imageCapture ?: return
        if (busy) return
        busy = true
        try {
            if ((mode == Mode.PRO || (mode == Mode.PHOTO && !hdr)) && !ai || (mode == Mode.PRO)) saveRaw(ic)
            else processedShot(ic)
        } catch (e: Throwable) {
            toast("Çekim hatası: ${e.message}")
        } finally { busy = false; status = null }
    }

    private suspend fun processedShot(ic: ImageCapture) {
        status = "Çekiliyor…"
        var rot = 0
        var base: Mat
        when {
            mode == Mode.NIGHT -> {
                val (first, r) = grabMat(ic); rot = r
                val luma = Enhancer.meanLuma(first)
                val n = if (luma < 45) 12 else 8
                val st = Enhancer.Stacker(first)
                for (i in 1 until n) {
                    status = "Gece modu: kare ${i + 1}/$n"
                    val (f, _) = grabMat(ic)
                    withContext(Dispatchers.Default) { st.addFrame(f) }; f.release()
                }
                first.release(); base = st.result()
            }
            mode == Mode.PHOTO && hdr && flash == ImageCapture.FLASH_MODE_OFF && evMax > evMin -> {
                val cam = camera!!
                val evs = listOf(0f, -2f, 2f); val frames = ArrayList<Mat>()
                val userEv = evIdx
                for ((i, ev) in evs.withIndex()) {
                    status = "HDR+: kare ${i + 1}/3"
                    cam.cameraControl.setExposureCompensationIndex(
                        (userEv + ev / evStep).roundToInt().coerceIn(evMin, evMax))
                    delay(450)
                    val (m, r) = grabMat(ic); rot = r; frames.add(m)
                }
                cam.cameraControl.setExposureCompensationIndex(userEv)
                status = "HDR+ birleştiriliyor…"
                base = withContext(Dispatchers.Default) {
                    val ref = frames[0]
                    val aligned = listOf(ref) + frames.drop(1).map { Enhancer.align(ref, it) ?: it.clone() }
                    val r = Enhancer.mertens(aligned)
                    frames.forEach { it.release() }; aligned.forEach { it.release() }
                    r
                }
            }
            else -> { val (m, r) = grabMat(ic); base = m; rot = r }
        }

        status = "Yapay zeka iyileştiriyor…"
        val out = withContext(Dispatchers.Default) {
            var img = Enhancer.rotate(base, rot)
            if (ai) {
                val luma = Enhancer.meanLuma(img)
                val small = org.opencv.core.Mat()
                org.opencv.imgproc.Imgproc.resize(img, small, org.opencv.core.Size(), 0.15, 0.15, org.opencv.imgproc.Imgproc.INTER_AREA)
                val sb = Enhancer.toBitmap(small); small.release()
                var scene = try { Enhancer.detectScene(sb) } catch (e: Exception) { Scene.AUTO }
                if (mode == Mode.NIGHT && scene == Scene.AUTO) scene = Scene.NIGHT
                if (mode == Mode.PORTRAIT) scene = Scene.PORTRAIT
                sceneLabel = scene.tr
                img = Enhancer.enhance(img, Enhancer.tuningFor(scene, luma))
            }
            if (mode == Mode.PORTRAIT) img = Enhancer.portrait(img, 1.0f, if (ai) 0.35f else 0f)
            val bmp = Enhancer.toBitmap(img); img.release(); bmp
        }
        status = "Kaydediliyor…"
        val uri = saveJpeg(out); out.recycle()
        uri?.let { lastUri = it; updateThumb(it) }
    }

    private suspend fun saveRaw(ic: ImageCapture) {
        status = "Kaydediliyor…"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KP_${stamp()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KameraPro")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        val uri = suspendCancellableCoroutine<Uri?> { c ->
            ic.takePicture(opts, io, object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) { c.resume(r.savedUri) }
                override fun onError(e: ImageCaptureException) { c.resumeWithException(e) }
            })
        }
        uri?.let { lastUri = it; updateThumb(it) }
    }

    private fun saveJpeg(bmp: Bitmap): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KP_${stamp()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KameraPro")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        r.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        if (Build.VERSION.SDK_INT >= 29) { cv.clear(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0); r.update(uri, cv, null, null) }
        return uri
    }

    private fun updateThumb(uri: Uri) {
        if (Build.VERSION.SDK_INT >= 29) runCatching { thumb = ctx.contentResolver.loadThumbnail(uri, Size(240, 240), null) }
    }

    // ---------- Video ----------
    @SuppressLint("MissingPermission")
    fun toggleRecord() {
        val vc = videoCapture ?: return
        if (recordingHandle != null) { recordingHandle?.stop(); return }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "KP_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/KameraPro")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var prep = vc.output.prepareRecording(ctx, opts)
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            prep = prep.withAudioEnabled()
        recSeconds = 0; recording = true
        recordingHandle = prep.start(main) { ev ->
            when (ev) {
                is VideoRecordEvent.Status -> recSeconds = (ev.recordingStats.recordedDurationNanos / 1_000_000_000L).toInt()
                is VideoRecordEvent.Finalize -> {
                    recordingHandle = null; recording = false
                    if (ev.hasError()) toast("Video hatası") else { lastUri = ev.outputResults.outputUri; updateThumb(ev.outputResults.outputUri) }
                }
                else -> {}
            }
        }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun toast(s: String) = main.execute { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() }
}
