package tr.kamerapro

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.tasks.await
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/** Sahne başına ince ayar. Değerler 0..1 aralığında (saturation çarpan). */
data class Tuning(
    val denoise: Float = 0.5f, val sharpen: Float = 0.7f, val clarity: Float = 0.25f,
    val vibrance: Float = 0.35f, val saturation: Float = 1.05f, val shadows: Float = 0.25f,
    val contrast: Float = 0.25f, val clahe: Float = 1.6f, val awb: Float = 0.4f, val warmth: Float = 0f
)

enum class Scene(val tr: String, val tuning: Tuning) {
    AUTO("Otomatik", Tuning()),
    PORTRAIT("Portre", Tuning(0.6f, 0.45f, 0.10f, 0.20f, 1.00f, 0.30f, 0.15f, 1.2f, 0.3f, 0.02f)),
    FOOD("Yemek", Tuning(0.4f, 0.8f, 0.35f, 0.6f, 1.12f, 0.2f, 0.3f, 1.8f, 0.2f, 0.03f)),
    LANDSCAPE("Manzara", Tuning(0.4f, 0.9f, 0.45f, 0.5f, 1.10f, 0.3f, 0.35f, 2.2f, 0.3f, 0f)),
    PLANT("Bitki", Tuning(0.4f, 0.8f, 0.30f, 0.55f, 1.10f, 0.25f, 0.3f, 1.8f, 0.3f, 0f)),
    TEXT("Belge", Tuning(0.5f, 1.3f, 0.40f, 0f, 1.00f, 0.1f, 0.4f, 2.5f, 0.5f, 0f)),
    NIGHT("Gece", Tuning(0.8f, 0.6f, 0.20f, 0.4f, 1.05f, 0.6f, 0.3f, 2.0f, 0.4f, 0f))
}

object Enhancer {
    @Volatile private var ready = false
    fun init() { if (!ready) ready = OpenCVLoader.initLocal() }

    private val labeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build())
    }
    private val segmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        )
    }

    // ---------- Giriş/çıkış ----------
    fun decode(bytes: ByteArray): Mat {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba); bmp.recycle()
        val rgb = Mat(); Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB); rgba.release()
        return rgb
    }

    fun toBitmap(rgb: Mat): Bitmap {
        val rgba = Mat(); Imgproc.cvtColor(rgb, rgba, Imgproc.COLOR_RGB2RGBA)
        val b = Bitmap.createBitmap(rgb.cols(), rgb.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, b); rgba.release()
        return b
    }

    fun rotate(m: Mat, deg: Int): Mat {
        val code = when (((deg % 360) + 360) % 360) {
            90 -> Core.ROTATE_90_CLOCKWISE
            180 -> Core.ROTATE_180
            270 -> Core.ROTATE_90_COUNTERCLOCKWISE
            else -> return m
        }
        val o = Mat(); Core.rotate(m, o, code); m.release(); return o
    }

    fun meanLuma(rgb: Mat): Double {
        val s = Mat(); Imgproc.resize(rgb, s, Size(), 0.1, 0.1, Imgproc.INTER_AREA)
        val g = Mat(); Imgproc.cvtColor(s, g, Imgproc.COLOR_RGB2GRAY)
        val v = Core.mean(g).`val`[0]; s.release(); g.release(); return v
    }

    // ---------- Yapay zeka: sahne tanıma ----------
    suspend fun detectScene(bmp: Bitmap): Scene {
        val labels = labeler.process(InputImage.fromBitmap(bmp, 0)).await().map { it.text.lowercase() }.toSet()
        fun any(vararg k: String) = k.any { it in labels }
        return when {
            any("selfie", "face", "smile", "skin", "forehead", "beard", "facial hair", "chin", "eyebrow", "cheek") -> Scene.PORTRAIT
            any("food", "dish", "cuisine", "meal", "fruit", "dessert", "baked goods", "vegetable", "drink") -> Scene.FOOD
            any("text", "paper", "document", "handwriting", "font", "book") -> Scene.TEXT
            any("sky", "sunset", "mountain", "sea", "beach", "landscape", "horizon", "cloud", "lake") -> Scene.LANDSCAPE
            any("plant", "flower", "tree", "leaf", "grass", "petal") -> Scene.PLANT
            any("night", "darkness") -> Scene.NIGHT
            else -> Scene.AUTO
        }
    }

    fun tuningFor(scene: Scene, luma: Double): Tuning {
        val t = scene.tuning
        return if (luma < 70) t.copy(shadows = max(t.shadows, 0.55f), denoise = min(1f, t.denoise + 0.25f)) else t
    }

    // ---------- Hizalama ----------
    private fun smallGray(m: Mat): Mat {
        val g = Mat(); Imgproc.cvtColor(m, g, Imgproc.COLOR_RGB2GRAY)
        val s = Mat(); Imgproc.resize(g, s, Size(), 0.25, 0.25, Imgproc.INTER_AREA); g.release()
        val f = Mat(); s.convertTo(f, CvType.CV_32F); s.release(); return f
    }

    /** frame'i ref'e hizalar. Çok farklıysa null (kare atlanır). */
    fun align(ref: Mat, frame: Mat): Mat? {
        val a = smallGray(ref); val b = smallGray(frame)
        val win = Mat(); Imgproc.createHanningWindow(win, a.size(), CvType.CV_32F)
        val resp = DoubleArray(1)
        val sh = Imgproc.phaseCorrelate(a, b, win, resp)
        fun cost(dx: Double, dy: Double): Double {
            val m = Mat(2, 3, CvType.CV_64F); m.put(0, 0, 1.0, 0.0, dx, 0.0, 1.0, dy)
            val w = Mat(); Imgproc.warpAffine(b, w, m, b.size(), Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
            val d = Mat(); Core.absdiff(a, w, d)
            val c = Core.mean(d).`val`[0]; m.release(); w.release(); d.release(); return c
        }
        var dx = 0.0; var dy = 0.0; var best = cost(0.0, 0.0)
        val c1 = cost(-sh.x, -sh.y); if (c1 < best) { best = c1; dx = -sh.x; dy = -sh.y }
        val c2 = cost(sh.x, sh.y); if (c2 < best) { best = c2; dx = sh.x; dy = sh.y }
        val limit = 0.12 * max(a.cols(), a.rows())
        a.release(); b.release(); win.release()
        if (best > 28.0 || hypot(dx, dy) > limit) return null
        val m = Mat(2, 3, CvType.CV_64F); m.put(0, 0, 1.0, 0.0, dx * 4, 0.0, 1.0, dy * 4)
        val out = Mat(); Imgproc.warpAffine(frame, out, m, frame.size(), Imgproc.INTER_LINEAR, Core.BORDER_REFLECT)
        m.release(); return out
    }

    /** Çoklu kare birleştirme: hizalama + hayalet (ghost) reddi + ağırlıklı ortalama. */
    class Stacker(private val ref: Mat) {
        private val acc = Mat.zeros(ref.size(), CvType.CV_32FC3)
        private val wsum = Mat.zeros(ref.size(), CvType.CV_32FC1)
        private val refG = Mat()
        var count = 0; private set

        init {
            Imgproc.cvtColor(ref, refG, Imgproc.COLOR_RGB2GRAY); refG.convertTo(refG, CvType.CV_32F)
            accumulate(ref, true)
        }

        fun addFrame(f: Mat) { val a = align(ref, f) ?: return; accumulate(a, false); a.release() }

        private fun weight(f: Mat): Mat {
            val g = Mat(); Imgproc.cvtColor(f, g, Imgproc.COLOR_RGB2GRAY); g.convertTo(g, CvType.CV_32F)
            val d = Mat(); Core.absdiff(g, refG, d); g.release()
            Imgproc.GaussianBlur(d, d, Size(7.0, 7.0), 0.0)
            Core.divide(d, Scalar(22.0), d); Core.multiply(d, d, d); Core.multiply(d, Scalar(-1.0), d)
            val w = Mat(); Core.exp(d, w); d.release(); return w
        }

        private fun accumulate(f: Mat, isRef: Boolean) {
            val ff = Mat(); f.convertTo(ff, CvType.CV_32F)
            val w = if (isRef) Mat(f.size(), CvType.CV_32F, Scalar(1.0)) else weight(f)
            val w3 = Mat(); Core.merge(listOf(w, w, w), w3)
            Core.multiply(ff, w3, ff); Core.add(acc, ff, acc); Core.add(wsum, w, wsum)
            ff.release(); w3.release(); w.release(); count++
        }

        fun result(): Mat {
            Core.add(wsum, Scalar(1e-6), wsum)
            val w3 = Mat(); Core.merge(listOf(wsum, wsum, wsum), w3)
            val o = Mat(); Core.divide(acc, w3, o)
            val o8 = Mat(); o.convertTo(o8, CvType.CV_8U)
            o.release(); w3.release(); acc.release(); wsum.release(); refG.release()
            return o8
        }
    }

    /** HDR: Mertens pozlama birleştirme (kareler önceden hizalanmış olmalı). */
    fun mertens(frames: List<Mat>): Mat {
        val mm = Photo.createMergeMertens()
        val out = Mat(); mm.process(frames, out)
        val o8 = Mat(); out.convertTo(o8, CvType.CV_8U, 255.0); out.release(); return o8
    }

    // ---------- Ana iyileştirme hattı (src tüketilir) ----------
    fun enhance(src: Mat, t: Tuning): Mat {
        if (t.awb > 0f) awb(src, t.awb, t.warmth)
        val dn = denoise(src, t.denoise)
        val lab = Mat(); Imgproc.cvtColor(dn, lab, Imgproc.COLOR_RGB2Lab); dn.release()
        val ch = ArrayList<Mat>(); Core.split(lab, ch); lab.release()
        var l = ch[0]
        if (t.clahe > 0f) {
            val c = Imgproc.createCLAHE(t.clahe.toDouble(), Size(8.0, 8.0))
            val l2 = Mat(); c.apply(l, l2); Core.addWeighted(l, 0.4, l2, 0.6, 0.0, l2); l.release(); l = l2
        }
        val lut = toneLut(t.shadows, t.contrast)
        val l3 = Mat(); Core.LUT(l, lut, l3); l.release(); lut.release()
        val ls = sharpenL(l3, t.sharpen, t.clarity); l3.release()
        ch[0].release(); ch[0] = ls
        val lab2 = Mat(); Core.merge(ch, lab2); ch.forEach { it.release() }
        val rgb = Mat(); Imgproc.cvtColor(lab2, rgb, Imgproc.COLOR_Lab2RGB); lab2.release()
        return vibrance(rgb, t.vibrance, t.saturation)
    }

    private fun awb(img: Mat, strength: Float, warmth: Float) {
        val m = Core.mean(img).`val`
        val avg = (m[0] + m[1] + m[2]) / 3
        fun gain(c: Double) = (1 + (avg / (c + 1e-3) - 1) * strength).coerceIn(0.88, 1.12)
        val gr = gain(m[0]) * (1 + warmth); val gg = gain(m[1]); val gb = gain(m[2]) * (1 - warmth)
        Core.multiply(img, Scalar(gr, gg, gb), img)
    }

    private fun denoise(rgb: Mat, s: Float): Mat {
        if (s <= 0.01f) return rgb
        val ycc = Mat(); Imgproc.cvtColor(rgb, ycc, Imgproc.COLOR_RGB2YCrCb); rgb.release()
        val ch = ArrayList<Mat>(); Core.split(ycc, ch); ycc.release()
        for (i in 1..2) { // renk gürültüsü: yarı çözünürlükte kenar korumalı filtre
            val sm = Mat(); Imgproc.resize(ch[i], sm, Size(), 0.5, 0.5, Imgproc.INTER_AREA)
            val f = Mat(); Imgproc.bilateralFilter(sm, f, 9, 25.0 + 40.0 * s, 7.0); sm.release()
            val up = Mat(); Imgproc.resize(f, up, ch[i].size(), 0.0, 0.0, Imgproc.INTER_LINEAR); f.release()
            ch[i].release(); ch[i] = up
        }
        val y = Mat(); Photo.fastNlMeansDenoising(ch[0], y, 2f + 7f * s, 5, 11)
        ch[0].release(); ch[0] = y
        val o = Mat(); Core.merge(ch, o); ch.forEach { it.release() }
        val out = Mat(); Imgproc.cvtColor(o, out, Imgproc.COLOR_YCrCb2RGB); o.release()
        return out
    }

    private fun toneLut(shadows: Float, contrast: Float): Mat {
        val d = ByteArray(256)
        for (i in 0..255) {
            val x = i / 255.0
            var y = x.pow(1.0 / (1.0 + shadows))
            val s = y * y * (3 - 2 * y)
            y = y * (1 - contrast) + s * contrast
            d[i] = (y.coerceIn(0.0, 1.0) * 255.0 + 0.5).toInt().toByte()
        }
        val lut = Mat(1, 256, CvType.CV_8U); lut.put(0, 0, d); return lut
    }

    private fun usm(base: Mat, sigma: Double, amt: Double, thr: Double): Mat {
        val bl = Mat(); Imgproc.GaussianBlur(base, bl, Size(0.0, 0.0), sigma)
        val d = Mat(); Core.subtract(base, bl, d); bl.release()
        val a = Mat(); Core.absdiff(d, Scalar(0.0), a)
        val den = Mat(); Core.add(a, Scalar(thr), den)
        val ratio = Mat(); Core.divide(a, den, ratio); a.release(); den.release()
        val dd = d.mul(ratio); d.release(); ratio.release()   // gürültüyü büyütmeyen yumuşak eşik
        val out = Mat(); Core.addWeighted(base, 1.0, dd, amt, 0.0, out); dd.release()
        return out
    }

    private fun sharpenL(l: Mat, amount: Float, clarity: Float): Mat {
        val f = Mat(); l.convertTo(f, CvType.CV_32F)
        val s1 = usm(f, 1.1, amount * 1.3, 3.0); f.release()
        val s2 = if (clarity > 0f) usm(s1, 6.0, clarity.toDouble(), 6.0).also { s1.release() } else s1
        val o = Mat(); s2.convertTo(o, CvType.CV_8U); s2.release(); return o
    }

    private fun vibrance(rgb: Mat, v: Float, sat: Float): Mat {
        val hsv = Mat(); Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV); rgb.release()
        val ch = ArrayList<Mat>(); Core.split(hsv, ch); hsv.release()
        val d = ByteArray(256)
        for (i in 0..255) {
            val s = i / 255.0
            d[i] = (min(1.0, s * (1 + v * (1 - s)) * sat) * 255.0 + 0.5).toInt().toByte()
        }
        val lut = Mat(1, 256, CvType.CV_8U); lut.put(0, 0, d)
        val s2 = Mat(); Core.LUT(ch[1], lut, s2); ch[1].release(); ch[1] = s2; lut.release()
        val m = Mat(); Core.merge(ch, m); ch.forEach { it.release() }
        val out = Mat(); Imgproc.cvtColor(m, out, Imgproc.COLOR_HSV2RGB); m.release(); return out
    }

    // ---------- Portre: kişi maskesi + gerçek diyafram (disk) bokeh + güzelleştirme ----------
    suspend fun portrait(rgb: Mat, blur: Float, beauty: Float): Mat {
        val mask = personMask(rgb)
        val base = if (beauty > 0f) beautify(rgb, mask, beauty) else rgb
        val bg = discBlur(base, blur)
        val out = blend(bg, base, mask)
        bg.release(); mask.release()
        if (base !== rgb) base.release()
        rgb.release()
        return out
    }

    private suspend fun personMask(rgb: Mat): Mat {
        val scale = 640.0 / max(rgb.cols(), rgb.rows())
        val small = Mat(); Imgproc.resize(rgb, small, Size(), scale, scale, Imgproc.INTER_AREA)
        val bmp = toBitmap(small)
        val m = Mat(small.rows(), small.cols(), CvType.CV_32F)
        try {
            val res = segmenter.process(InputImage.fromBitmap(bmp, 0)).await()
            val arr = FloatArray(res.width * res.height)
            res.buffer.rewind(); res.buffer.asFloatBuffer().get(arr)
            val raw = Mat(res.height, res.width, CvType.CV_32F); raw.put(0, 0, arr)
            if (raw.size() == m.size()) raw.copyTo(m) else Imgproc.resize(raw, m, m.size())
            raw.release()
        } catch (e: Exception) { m.setTo(Scalar(0.0)) }
        bmp.recycle(); small.release()
        if (Core.mean(m).`val`[0] < 0.03) { // kişi yok (nesne/manzara): merkez odaklı elips maske
            val e = Mat.zeros(m.size(), CvType.CV_8U)
            Imgproc.ellipse(e, Point(m.cols() / 2.0, m.rows() * 0.5), Size(m.cols() * 0.32, m.rows() * 0.28),
                0.0, 0.0, 360.0, Scalar(255.0), -1)
            e.convertTo(m, CvType.CV_32F, 1.0 / 255.0); e.release()
        }
        val full = Mat(); Imgproc.resize(m, full, rgb.size(), 0.0, 0.0, Imgproc.INTER_CUBIC); m.release()
        full.convertTo(full, CvType.CV_32F, 2.2, -0.6)               // kenarı sıkılaştır
        Imgproc.threshold(full, full, 1.0, 1.0, Imgproc.THRESH_TRUNC)
        Imgproc.threshold(full, full, 0.0, 0.0, Imgproc.THRESH_TOZERO)
        val sig = max(rgb.cols(), rgb.rows()) / 600.0
        Imgproc.GaussianBlur(full, full, Size(0.0, 0.0), sig)         // yumuşak geçiş
        return full
    }

    private fun beautify(rgb: Mat, mask: Mat, amount: Float): Mat {
        val half = Mat(); Imgproc.resize(rgb, half, Size(), 0.5, 0.5, Imgproc.INTER_AREA)
        val sm = Mat(); Imgproc.bilateralFilter(half, sm, 9, 35.0, 9.0); half.release()
        val up = Mat(); Imgproc.resize(sm, up, rgb.size(), 0.0, 0.0, Imgproc.INTER_LINEAR); sm.release()
        val m = Mat(); Core.multiply(mask, Scalar(amount.toDouble()), m)
        val out = blend(rgb, up, m); up.release(); m.release(); return out
    }

    private fun disc(r: Int): Mat {
        val n = 2 * r + 1; val a = FloatArray(n * n); var sum = 0f
        for (y in 0 until n) for (x in 0 until n) {
            val d = hypot((x - r).toDouble(), (y - r).toDouble())
            val v = (r + 0.5 - d).coerceIn(0.0, 1.0).toFloat(); a[y * n + x] = v; sum += v
        }
        for (i in a.indices) a[i] /= sum
        val k = Mat(n, n, CvType.CV_32F); k.put(0, 0, a); return k
    }

    private fun discBlur(base: Mat, strength: Float): Mat {
        val sm = Mat(); Imgproc.resize(base, sm, Size(), 0.25, 0.25, Imgproc.INTER_AREA)
        val f = Mat(); sm.convertTo(f, CvType.CV_32F, 1.0 / 255.0)
        Core.pow(f, 2.2, f)                                           // lineer ışıkta bulanıklaştır: parlak noktalar bokeh topu olur
        val r = (min(sm.cols(), sm.rows()) / 38.0 * strength).roundToInt().coerceIn(3, 22)
        val k = disc(r)
        val fb = Mat(); Imgproc.filter2D(f, fb, -1, k, Point(-1.0, -1.0), 0.0, Core.BORDER_REFLECT)
        Core.pow(fb, 1 / 2.2, fb)
        val b8 = Mat(); fb.convertTo(b8, CvType.CV_8U, 255.0)
        val full = Mat(); Imgproc.resize(b8, full, base.size(), 0.0, 0.0, Imgproc.INTER_CUBIC)
        sm.release(); f.release(); fb.release(); b8.release(); k.release()
        return full
    }

    /** a + (b - a) * m   (m: 32F tek kanal) */
    private fun blend(a: Mat, b: Mat, m: Mat): Mat {
        val af = Mat(); a.convertTo(af, CvType.CV_32F)
        val bf = Mat(); b.convertTo(bf, CvType.CV_32F)
        Core.subtract(bf, af, bf)
        val m3 = Mat(); Core.merge(listOf(m, m, m), m3)
        Core.multiply(bf, m3, bf); Core.add(af, bf, af)
        val out = Mat(); af.convertTo(out, CvType.CV_8U)
        af.release(); bf.release(); m3.release(); return out
    }
}
